d(source_url)  # 이미지 로드
        self.qPixmapFileVar = se